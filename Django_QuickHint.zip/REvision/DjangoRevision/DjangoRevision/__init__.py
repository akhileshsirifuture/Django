"""
Package for DjangoRevision.
"""
